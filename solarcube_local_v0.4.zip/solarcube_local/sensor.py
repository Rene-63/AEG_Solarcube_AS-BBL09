"""Sensor platform for Solarcube Local.

Matches the real EnergyParameter payload structure:

    {
      "Response": "EnergyParameter",
      "Storage_list": [
        {"DevAddr": 1, "StorageSN": "...", "StorageStatus": 1,
         "BatterySoc": 10, "PvChargingPower": 0, "AcChargingPower": 40,
         "BatteryDischargingPower": 40, "BatteryChargingPower": 0,
         "AcInActivePower": -40, "OffGridLoadPower": 0,
         "PvStringCount": 4, "Pv1Power": 0, ... "Pv4Power": 0}
      ],
      "SSumInfoList": {
        "ControlEnableStatus": 1, "MeterTotalActivePower": 456,
        "TotalPVPower": 0, "TotalPVChargePower": 0, "TotalACChargePower": 4,
        "TotalSmartLoadElectricalPower": 0, "AverageBatteryAverageSOC": 10,
        "TotalBatteryOutputPower": 4, "TotalGridOutputPower": -4,
        "TotalBackUpPower": 0, "TotalChargePower": 0
      }
    }
"""

from __future__ import annotations

from collections.abc import Callable
import logging
from dataclasses import dataclass
from typing import Any

from homeassistant.components.sensor import (
    SensorDeviceClass,
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass,
)
from homeassistant.const import PERCENTAGE, EntityCategory, UnitOfPower
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import (
    CONF_HOST,
    DOMAIN,
    MAX_PLAUSIBLE_STORAGE_POWER,
    SPIKE_CONFIRM_FRACTION,
    SPIKE_JUMP_FRACTION,
)
from .coordinator import SolarcubeConfigEntry, SolarcubeCoordinator

_LOGGER = logging.getLogger(__name__)


def _to_float(value: Any) -> float | None:
    """Coerce firmware values (sometimes strings) to float."""
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _sum_info(data: dict[str, Any]) -> dict[str, Any]:
    """Return the SSumInfoList block (dict) from the payload."""
    block = data.get("SSumInfoList")
    return block if isinstance(block, dict) else {}


def _storage_list(data: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the Storage_list block from the payload."""
    block = data.get("Storage_list")
    return block if isinstance(block, list) else []


def _storage_by_sn(data: dict[str, Any], sn: str) -> dict[str, Any]:
    """Return the storage entry for a serial number."""
    for item in _storage_list(data):
        if item.get("StorageSN") == sn:
            return item
    return {}


@dataclass(frozen=True, kw_only=True)
class SolarcubeSensorDescription(SensorEntityDescription):
    """Describes a Solarcube sensor reading one payload field."""

    field: str
    is_float: bool = True
    max_abs: float | None = None


def _sum_power(key: str, field: str, **kwargs: Any) -> SolarcubeSensorDescription:
    """Shorthand for a W sensor in SSumInfoList."""
    return SolarcubeSensorDescription(
        key=key,
        translation_key=key,
        field=field,
        device_class=SensorDeviceClass.POWER,
        native_unit_of_measurement=UnitOfPower.WATT,
        state_class=SensorStateClass.MEASUREMENT,
        **kwargs,
    )


# --- System totals (SSumInfoList) ------------------------------------------

SUM_SENSORS: tuple[SolarcubeSensorDescription, ...] = (
    _sum_power("meter_total_active_power", "MeterTotalActivePower"),
    _sum_power("total_pv_power", "TotalPVPower"),
    _sum_power("total_pv_charge_power", "TotalPVChargePower"),
    _sum_power("total_ac_charge_power", "TotalACChargePower"),
    _sum_power("total_charge_power", "TotalChargePower"),
    _sum_power("total_battery_output_power", "TotalBatteryOutputPower"),
    _sum_power("total_grid_output_power", "TotalGridOutputPower"),
    _sum_power("total_backup_power", "TotalBackUpPower"),
    _sum_power(
        "total_smart_load_power",
        "TotalSmartLoadElectricalPower",
        entity_registry_enabled_default=False,
    ),
    SolarcubeSensorDescription(
        key="average_battery_soc",
        translation_key="average_battery_soc",
        field="AverageBatteryAverageSOC",
        device_class=SensorDeviceClass.BATTERY,
        native_unit_of_measurement=PERCENTAGE,
        state_class=SensorStateClass.MEASUREMENT,
    ),
    SolarcubeSensorDescription(
        key="control_enable_status",
        translation_key="control_enable_status",
        field="ControlEnableStatus",
        entity_category=EntityCategory.DIAGNOSTIC,
        is_float=False,
    ),
)

# --- Per battery module / storage unit (Storage_list) ----------------------


def _storage_power(key: str, field: str, **kwargs: Any) -> SolarcubeSensorDescription:
    """Shorthand for a W sensor in a Storage_list entry."""
    return SolarcubeSensorDescription(
        key=key,
        translation_key=key,
        field=field,
        device_class=SensorDeviceClass.POWER,
        native_unit_of_measurement=UnitOfPower.WATT,
        state_class=SensorStateClass.MEASUREMENT,
        max_abs=MAX_PLAUSIBLE_STORAGE_POWER,
        **kwargs,
    )


STORAGE_SENSORS: tuple[SolarcubeSensorDescription, ...] = (
    SolarcubeSensorDescription(
        key="battery_soc",
        translation_key="battery_soc",
        field="BatterySoc",
        device_class=SensorDeviceClass.BATTERY,
        native_unit_of_measurement=PERCENTAGE,
        state_class=SensorStateClass.MEASUREMENT,
    ),
    _storage_power("pv_charging_power", "PvChargingPower"),
    _storage_power("ac_charging_power", "AcChargingPower"),
    _storage_power("battery_charging_power", "BatteryChargingPower"),
    _storage_power("battery_discharging_power", "BatteryDischargingPower"),
    _storage_power("ac_in_active_power", "AcInActivePower"),
    _storage_power("off_grid_load_power", "OffGridLoadPower"),
    _storage_power("pv1_power", "Pv1Power", entity_registry_enabled_default=False),
    _storage_power("pv2_power", "Pv2Power", entity_registry_enabled_default=False),
    _storage_power("pv3_power", "Pv3Power", entity_registry_enabled_default=False),
    _storage_power("pv4_power", "Pv4Power", entity_registry_enabled_default=False),
    SolarcubeSensorDescription(
        key="storage_status",
        translation_key="storage_status",
        field="StorageStatus",
        entity_category=EntityCategory.DIAGNOSTIC,
        is_float=False,
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: SolarcubeConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Create entities for fields the device actually reports."""
    coordinator = entry.runtime_data
    data = coordinator.data or {}
    entities: list[SensorEntity] = []

    sum_block = _sum_info(data)
    entities.extend(
        SolarcubeSumSensor(coordinator, entry, description)
        for description in SUM_SENSORS
        if description.field in sum_block
    )

    for storage in _storage_list(data):
        sn = storage.get("StorageSN")
        if not sn:
            continue
        entities.extend(
            SolarcubeStorageSensor(coordinator, entry, description, sn)
            for description in STORAGE_SENSORS
            if description.field in storage
        )

    async_add_entities(entities)


class SolarcubeBaseSensor(
    CoordinatorEntity[SolarcubeCoordinator], SensorEntity
):
    """Common base."""

    _attr_has_entity_name = True
    entity_description: SolarcubeSensorDescription
    _last_good: Any = None
    _pending_spike: Any = None

    def _convert(self, value: Any) -> Any:
        if not self.entity_description.is_float:
            return value
        value = _to_float(value)
        if value is None:
            return None

        max_abs = self.entity_description.max_abs
        if max_abs is None:
            self._last_good = value
            return value

        # 1. Hard ceiling: physically impossible reading, always reject.
        if abs(value) > max_abs:
            _LOGGER.debug(
                "Implausible %s reading rejected (ceiling): %s W (max %s W)",
                self.entity_description.key,
                value,
                max_abs,
            )
            self._pending_spike = None
            return self._last_good

        # 2. Spike detection: a sudden jump that doesn't repeat is a glitch.
        #    A value far from the last good one is held back once; only if the
        #    next reading confirms it (close to the suspect value) is it
        #    accepted. This rejects one-off firmware spikes without lagging
        #    behind genuine fast changes for more than a single cycle.
        if self._last_good is not None:
            jump = abs(value - self._last_good)
            if jump > max_abs * SPIKE_JUMP_FRACTION:
                if self._pending_spike is None or abs(
                    value - self._pending_spike
                ) > max_abs * SPIKE_CONFIRM_FRACTION:
                    _LOGGER.debug(
                        "Suspected %s spike held back: %s W (last good %s W)",
                        self.entity_description.key,
                        value,
                        self._last_good,
                    )
                    self._pending_spike = value
                    return self._last_good

        # Accepted (normal reading, or a confirmed real change).
        self._pending_spike = None
        self._last_good = value
        return value


class SolarcubeSumSensor(SolarcubeBaseSensor):
    """System-wide value from SSumInfoList."""

    def __init__(
        self,
        coordinator: SolarcubeCoordinator,
        entry: SolarcubeConfigEntry,
        description: SolarcubeSensorDescription,
    ) -> None:
        """Initialize the sensor."""
        super().__init__(coordinator)
        self.entity_description = description
        self._attr_unique_id = f"{entry.entry_id}_sum_{description.key}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name=f"Solarcube ({entry.data[CONF_HOST]})",
            manufacturer="AEG / Sunpura",
            model="Solarcube",
        )

    @property
    def native_value(self) -> Any:
        """Return the current value."""
        return self._convert(
            _sum_info(self.coordinator.data).get(self.entity_description.field)
        )


class SolarcubeStorageSensor(SolarcubeBaseSensor):
    """Per storage unit value from Storage_list, keyed by serial number."""

    def __init__(
        self,
        coordinator: SolarcubeCoordinator,
        entry: SolarcubeConfigEntry,
        description: SolarcubeSensorDescription,
        storage_sn: str,
    ) -> None:
        """Initialize the sensor."""
        super().__init__(coordinator)
        self.entity_description = description
        self._storage_sn = storage_sn
        self._attr_unique_id = f"{entry.entry_id}_{storage_sn}_{description.key}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, f"{entry.entry_id}_{storage_sn}")},
            name=f"Solarcube opslag {storage_sn}",
            manufacturer="AEG / Sunpura",
            model="Solarcube storage unit",
            serial_number=storage_sn,
            via_device=(DOMAIN, entry.entry_id),
        )

    @property
    def native_value(self) -> Any:
        """Return the current value."""
        return self._convert(
            _storage_by_sn(self.coordinator.data, self._storage_sn).get(
                self.entity_description.field
            )
        )
