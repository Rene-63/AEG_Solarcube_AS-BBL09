"""Async TCP client for the AEG Solarcube / Sunpura local JSON protocol.

The device speaks newline-delimited JSON over a plain TCP socket:

    {"Get": "<Command>", "SerialNumber": <n>, "CommandSource": "HA", ...}

Responses echo the command in ``Response`` and the serial number in
``SerialNumber``. A single persistent connection is used; requests are
serialized with a lock so responses can be matched to requests.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from .const import (
    CMD_ENERGY_CONTROL,
    CMD_ENERGY_PARAMETER,
    CONTROL_FIELDS,
    RESPONSE_TIMEOUT,
)

_LOGGER = logging.getLogger(__name__)


class SolarcubeConnectionError(Exception):
    """Raised when the device cannot be reached."""


class SolarcubeProtocolError(Exception):
    """Raised when the device returns an unexpected response."""


class SolarcubeLocalClient:
    """Persistent TCP client for one device."""

    def __init__(self, host: str, port: int) -> None:
        self.host = host
        self.port = port
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        self._lock = asyncio.Lock()
        self._serial = 0
        self._buffer = ""

    @property
    def connected(self) -> bool:
        """Return True if a usable connection exists."""
        return self._writer is not None and not self._writer.is_closing()

    async def connect(self) -> None:
        """Open the TCP connection if not already open."""
        if self.connected:
            return
        try:
            self._reader, self._writer = await asyncio.wait_for(
                asyncio.open_connection(self.host, self.port),
                timeout=RESPONSE_TIMEOUT,
            )
        except (OSError, asyncio.TimeoutError) as err:
            raise SolarcubeConnectionError(
                f"Cannot connect to {self.host}:{self.port}: {err}"
            ) from err
        self._buffer = ""
        _LOGGER.debug("Connected to %s:%s", self.host, self.port)

    async def disconnect(self) -> None:
        """Close the connection."""
        if self._writer is not None:
            self._writer.close()
            try:
                await self._writer.wait_closed()
            except OSError:
                pass
        self._reader = None
        self._writer = None
        self._buffer = ""

    async def _request(self, message: dict[str, Any]) -> dict[str, Any]:
        """Send one request and return the matching response.

        Retries once on a broken connection.
        """
        async with self._lock:
            self._serial += 1
            message = {**message, "SerialNumber": self._serial, "CommandSource": "HA"}
            payload = json.dumps(message) + "\n"
            expected_cmd = message.get("Get") or message.get("Set")

            for attempt in (1, 2):
                try:
                    await self.connect()
                    assert self._writer is not None and self._reader is not None
                    self._writer.write(payload.encode("utf-8"))
                    await self._writer.drain()
                    return await asyncio.wait_for(
                        self._read_response(expected_cmd, self._serial),
                        timeout=RESPONSE_TIMEOUT,
                    )
                except (OSError, asyncio.IncompleteReadError, asyncio.TimeoutError) as err:
                    await self.disconnect()
                    if attempt == 2:
                        raise SolarcubeConnectionError(
                            f"Request {expected_cmd} failed: {err}"
                        ) from err
                    _LOGGER.debug(
                        "Connection error on %s, reconnecting: %s", expected_cmd, err
                    )
            raise SolarcubeConnectionError("unreachable")  # pragma: no cover

    async def _read_response(
        self, expected_cmd: str | None, expected_serial: int
    ) -> dict[str, Any]:
        """Read until a JSON object matching the request arrives."""
        assert self._reader is not None
        decoder = json.JSONDecoder()
        while True:
            chunk = await self._reader.read(4096)
            if not chunk:
                raise asyncio.IncompleteReadError(partial=b"", expected=1)
            self._buffer += chunk.decode("utf-8", errors="replace")

            while self._buffer:
                stripped = self._buffer.lstrip()
                try:
                    payload, index = decoder.raw_decode(stripped)
                except json.JSONDecodeError:
                    break  # incomplete frame, read more
                self._buffer = stripped[index:]
                if not isinstance(payload, dict):
                    continue
                if (
                    payload.get("Response") in (expected_cmd, None)
                    and payload.get("SerialNumber") == expected_serial
                ):
                    return payload
                _LOGGER.debug("Discarding unmatched frame: %s", payload)

    # ---- High-level API -------------------------------------------------

    async def async_get_energy_parameters(self) -> dict[str, Any]:
        """Return live energy values (power flows, SOC, voltages...)."""
        return await self._request({"Get": CMD_ENERGY_PARAMETER})

    async def async_get_control_parameters(
        self, fields: list[str] | None = None
    ) -> dict[str, Any]:
        """Return control registers (modes, power limits, schedules)."""
        return await self._request(
            {
                "Get": CMD_ENERGY_CONTROL,
                "RegControlField": fields or CONTROL_FIELDS,
            }
        )

    async def async_set_control_parameters(
        self, parameters: dict[str, Any]
    ) -> dict[str, Any]:
        """Write control registers. Use with care."""
        return await self._request(
            {
                "Set": CMD_ENERGY_CONTROL,
                "SetControlInfoField": parameters,
            }
        )
