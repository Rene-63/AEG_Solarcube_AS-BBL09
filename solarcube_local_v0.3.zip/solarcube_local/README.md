# Solarcube Local (AEG / Sunpura) — schone HA-integratie

Een Home Assistant custom integration die **rechtstreeks via je LAN**
(TCP, newline-delimited JSON) met de AEG Solarcube / Sunpura praat.
Gebouwd volgens de HA-richtlijnen, als schoon alternatief voor de
local mode van de vendor-integratie (HA-EMS). Kan ernaast draaien.

## Verschillen met de vendor-integratie

| | Vendor (ha_ems) | Deze integratie |
|---|---|---|
| Sensoren | ~50 pseudo-sensoren (state = timestamp, data in attributes) | Echte sensoren met device class, eenheid en state class |
| Polling | Eigen schedulers | `DataUpdateCoordinator`, interval instelbaar (1–300 s) |
| Energy dashboard | Niet bruikbaar | Vermogenssensoren direct bruikbaar (W, measurement) |
| Besturing | Pseudo-sensoren als RPC-kanaal | Nette services met response |
| Logging | INFO-flood (Chinees) | DEBUG, stil in normaal gebruik |
| Cloud | Vereist voor setup | Volledig lokaal, geen account |

## Installatie

1. Kopieer de map `solarcube_local` naar `/config/custom_components/`.
2. Herstart Home Assistant.
3. Instellingen → Apparaten & Services → Integratie toevoegen →
   "Solarcube Local".
4. Vul het IP-adres van de Solarcube in en de TCP-poort.

**Poort vinden:** de vendor-integratie ontdekt apparaten via mDNS
(`_http._tcp.local.`) en leest de poort uit de TXT-records (`s_port`).
Op je HA-host: `avahi-browse -r _http._tcp` en zoek het record met
een `s_sn`-property (serienummer), of kijk in de logs van de
vendor-integratie. Pas daarna eventueel de default (8899) aan.

## Sensoren

Batterij-SOC (%), batterijspanning (V), batterijtemperatuur (°C),
PV-vermogen totaal + per string, laadvermogen, verbruiksvermogen,
netvermogen, backup-vermogen, e.d. — alleen velden die jouw apparaat
daadwerkelijk rapporteert worden als entiteit aangemaakt.
Tekenconventie (laden vs. ontladen positief/negatief) is niet
gedocumenteerd door de fabrikant: controleer dit met live waarden.

## Besturing (services)

Lezen:
```yaml
action: solarcube_local.get_control_parameters
data:
  fields: ["EnergyManagement", "SystemMaxPowerLimit", "BaseDischargePower"]
response_variable: regs
```

Schrijven (voorzichtig — dit schrijft registers in de omvormer):
```yaml
action: solarcube_local.set_control_parameters
data:
  parameters:
    SystemMaxPowerLimit: 2400
```

Bekende registervelden uit het vendor-protocol: `EnergyManagement`,
`BaseDischargePower`, `ScheduledModeEnabled`, `PhaseDetectionEnabled`,
`MeterSelector`, `SystemMaxPowerLimit`, `PowerControlPeriod1..16`,
`PeriodValidTimestamp`.

## Beperkingen / disclaimer

- Geschreven op basis van reverse engineering van de vendor-code,
  **niet getest tegen een echt apparaat**. De TCP-protocollaag is wel
  getest tegen een mock-server (serial matching, reconnect,
  push-frames).
- Veldnamen in `EnergyParameter` zijn afgeleid uit het vendor-paneel;
  ontbrekende velden worden simpelweg niet als sensor aangemaakt.
  Check na de eerste verbinding het debug-log voor de werkelijke keys
  en breid `sensor.py` desgewenst uit.
- Schrijven van regelparameters gebeurt op eigen risico.
