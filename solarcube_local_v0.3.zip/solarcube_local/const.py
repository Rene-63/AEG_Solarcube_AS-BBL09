"""Constants for the Solarcube Local integration."""

from __future__ import annotations

DOMAIN = "solarcube_local"

CONF_HOST = "host"
CONF_PORT = "port"
CONF_SCAN_INTERVAL = "scan_interval"

DEFAULT_PORT = 8080
DEFAULT_SCAN_INTERVAL = 5  # seconds
MIN_SCAN_INTERVAL = 1
MAX_SCAN_INTERVAL = 300

RESPONSE_TIMEOUT = 5  # seconds

# Local TCP protocol commands (newline-delimited JSON).
CMD_ENERGY_PARAMETER = "EnergyParameter"
CMD_ENERGY_CONTROL = "Energycontrolparameters"

# Known control register fields, taken from the vendor protocol.
CONTROL_FIELDS = [
    "EnergyManagement",
    "BaseDischargePower",
    "ScheduledModeEnabled",
    "PhaseDetectionEnabled",
    "MeterSelector",
    "SystemMaxPowerLimit",
    "PeriodValidTimestamp",
]

SERVICE_GET_CONTROL_PARAMS = "get_control_parameters"
SERVICE_SET_CONTROL_PARAMS = "set_control_parameters"

ATTR_FIELDS = "fields"
ATTR_PARAMETERS = "parameters"

# Number of consecutive failed polls tolerated before entities go unavailable.
MAX_CONSECUTIVE_FAILURES = 3

# Plausibility ceiling (W) for per-storage power readings. The S2400 charges
# at ~2400 W max and is socket-connected (hard physical limit ~3680 W), so
# higher absolute readings are firmware glitches and are ignored.
MAX_PLAUSIBLE_STORAGE_POWER = 4000
