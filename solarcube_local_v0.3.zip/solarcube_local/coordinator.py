"""Data update coordinator for Solarcube Local."""

from __future__ import annotations

from datetime import timedelta
import logging
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import SolarcubeConnectionError, SolarcubeLocalClient
from .const import (
    CONF_SCAN_INTERVAL,
    DEFAULT_SCAN_INTERVAL,
    DOMAIN,
    MAX_CONSECUTIVE_FAILURES,
)

_LOGGER = logging.getLogger(__name__)

type SolarcubeConfigEntry = ConfigEntry[SolarcubeCoordinator]


class SolarcubeCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Polls EnergyParameter on a fixed interval."""

    config_entry: SolarcubeConfigEntry

    def __init__(
        self,
        hass: HomeAssistant,
        entry: SolarcubeConfigEntry,
        client: SolarcubeLocalClient,
    ) -> None:
        """Initialize the coordinator."""
        interval = entry.options.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL)
        super().__init__(
            hass,
            _LOGGER,
            config_entry=entry,
            name=DOMAIN,
            update_interval=timedelta(seconds=interval),
        )
        self.client = client
        self._consecutive_failures = 0

    async def _async_update_data(self) -> dict[str, Any]:
        """Fetch live values from the device.

        Tolerates up to MAX_CONSECUTIVE_FAILURES missed polls by returning
        the last known data, so a single slow response at a short polling
        interval does not flap all entities to unavailable.
        """
        try:
            data = await self.client.async_get_energy_parameters()
        except SolarcubeConnectionError as err:
            self._consecutive_failures += 1
            if self.data and self._consecutive_failures <= MAX_CONSECUTIVE_FAILURES:
                _LOGGER.debug(
                    "Poll failed (%d/%d), keeping last data: %s",
                    self._consecutive_failures,
                    MAX_CONSECUTIVE_FAILURES,
                    err,
                )
                return self.data
            raise UpdateFailed(str(err)) from err
        self._consecutive_failures = 0
        return data
