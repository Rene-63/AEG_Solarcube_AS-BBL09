"""The Solarcube Local integration."""

from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol

from homeassistant.const import Platform
from homeassistant.core import (
    HomeAssistant,
    ServiceCall,
    ServiceResponse,
    SupportsResponse,
)
from homeassistant.exceptions import HomeAssistantError
import homeassistant.helpers.config_validation as cv

from .api import SolarcubeConnectionError, SolarcubeLocalClient
from .const import (
    ATTR_FIELDS,
    ATTR_PARAMETERS,
    CONF_HOST,
    CONF_PORT,
    DOMAIN,
    SERVICE_GET_CONTROL_PARAMS,
    SERVICE_SET_CONTROL_PARAMS,
)
from .coordinator import SolarcubeConfigEntry, SolarcubeCoordinator

_LOGGER = logging.getLogger(__name__)

PLATFORMS: list[Platform] = [Platform.SENSOR]

GET_CONTROL_SCHEMA = vol.Schema(
    {
        vol.Optional(ATTR_FIELDS): vol.All(cv.ensure_list, [cv.string]),
    }
)
SET_CONTROL_SCHEMA = vol.Schema(
    {
        vol.Required(ATTR_PARAMETERS): dict,
    }
)


async def async_setup_entry(hass: HomeAssistant, entry: SolarcubeConfigEntry) -> bool:
    """Set up Solarcube Local from a config entry."""
    client = SolarcubeLocalClient(entry.data[CONF_HOST], entry.data[CONF_PORT])
    coordinator = SolarcubeCoordinator(hass, entry, client)
    await coordinator.async_config_entry_first_refresh()

    entry.runtime_data = coordinator
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    entry.async_on_unload(entry.add_update_listener(_async_update_listener))

    _async_register_services(hass, entry)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: SolarcubeConfigEntry) -> bool:
    """Unload a config entry."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        await entry.runtime_data.client.disconnect()
    return unload_ok


async def _async_update_listener(
    hass: HomeAssistant, entry: SolarcubeConfigEntry
) -> None:
    """Reload the entry when options (scan interval) change."""
    await hass.config_entries.async_reload(entry.entry_id)


def _async_register_services(
    hass: HomeAssistant, entry: SolarcubeConfigEntry
) -> None:
    """Register control services (idempotent)."""

    def _client() -> SolarcubeLocalClient:
        return entry.runtime_data.client

    async def get_control(call: ServiceCall) -> ServiceResponse:
        try:
            return await _client().async_get_control_parameters(
                call.data.get(ATTR_FIELDS)
            )
        except SolarcubeConnectionError as err:
            raise HomeAssistantError(str(err)) from err

    async def set_control(call: ServiceCall) -> ServiceResponse:
        params: dict[str, Any] = call.data[ATTR_PARAMETERS]
        _LOGGER.info("Writing control parameters: %s", params)
        try:
            return await _client().async_set_control_parameters(params)
        except SolarcubeConnectionError as err:
            raise HomeAssistantError(str(err)) from err

    if not hass.services.has_service(DOMAIN, SERVICE_GET_CONTROL_PARAMS):
        hass.services.async_register(
            DOMAIN,
            SERVICE_GET_CONTROL_PARAMS,
            get_control,
            schema=GET_CONTROL_SCHEMA,
            supports_response=SupportsResponse.ONLY,
        )
    if not hass.services.has_service(DOMAIN, SERVICE_SET_CONTROL_PARAMS):
        hass.services.async_register(
            DOMAIN,
            SERVICE_SET_CONTROL_PARAMS,
            set_control,
            schema=SET_CONTROL_SCHEMA,
            supports_response=SupportsResponse.OPTIONAL,
        )
